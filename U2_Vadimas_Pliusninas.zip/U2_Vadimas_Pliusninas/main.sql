CREATE DATABASE Kursas; 

CREATE TABLE Kurso_Autorius (
autoriaus_id INT(6),
vardas varchar(30) NOT NULL,
pavarde varchar(30) NOT NULL,
PRIMARY KEY (autoriaus_id),
FOREIGN KEY (kurso_id) REFERENCES Kursas(kurso_id)
)


CREATE TABLE Kursas (
kurso_id INT(6),
kurso_pavadinimas varchar(30) NOT NULL,
ikelimo_data TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
kurso_trumpas_aprasas varchar(200) NOT NULL,
kurso_platesnis_aprasas varchar(1000) NOT NULL,
pathinfo("/images/*",PATHINFO_BASENAME),
kurso_populiarumas int(4) NOT NULL,
kurso_kometarai varchar(100) NOT NULL,
kurso_kaina int(4) NOT NULL,
kurso_reitingas int(1) NOT NULL,
PRIMARY KEY (kurso_id)
)



