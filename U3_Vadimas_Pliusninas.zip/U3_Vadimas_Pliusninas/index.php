<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>U1_Vadimas_Pliusninas</title>
    <link rel="stylesheet" href="styles/style.css">
    <script src="js/script.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Exo:wght@200;400&display=swap" rel="stylesheet">

</head>

<body>
    <!--Header-->

    <header class="header">
        <img src="images/logo.png" alt="Logo">
    </header>

    <!--Courses List -->

    <section class="section-1">
        <h2>Naujausi kursai</h2>
        <main class="flex-container">
            <div class="card">
                <img src="images/php.jpg" alt="PHP kursai">
                <h4>PHP Pagrindai</h4>
                <p>Autorius</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, tenetur quae expedita quibusdam fugiat reprehenderit unde autem illo tempora! Voluptatem nulla maxime sequi voluptatibus? Voluptatibus provident id corporis fugit enim?</p>
                <div class="reiting">
                    <div class="reiting-points"></div>
                    <div class="feedback"> </div>
                </div>

            </div>
            <div class="card">
                <img src="images/css.jpg" alt="HTML/SCC Įvadas">
                <h4>HTML/SCC Įvadas</h4>
                <p>Autorius</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, tenetur quae expedita quibusdam fugiat reprehenderit unde autem illo tempora! Voluptatem nulla maxime sequi voluptatibus? Voluptatibus provident id corporis fugit enim?</p>
                <div class="reiting">
                    <div class="reiting-points"></div>
                    <div class="feedback"> </div>
                </div>

                <div class="card">
                    <img src="images/git.jpg" alt="Pažintis su GIT">
                    <h4>Pažintis su GIT</h4>
                    <p>Autorius</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, tenetur quae expedita quibusdam fugiat reprehenderit unde autem illo tempora! Voluptatem nulla maxime sequi voluptatibus? Voluptatibus provident id corporis fugit enim?</p>
                    <div class="reiting">
                        <div class="reiting-points"></div>
                        <div class="feedback"> </div>
                    </div>

                    <div class="card">
                        <img src="images/js.jpg" alt="JavaScript Žaliems">
                        <h4>JavaScript Žaliems</h4>
                        <p>Autorius</p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, tenetur quae expedita quibusdam fugiat reprehenderit unde autem illo tempora! Voluptatem nulla maxime sequi voluptatibus? Voluptatibus provident id corporis fugit
                            enim?
                        </p>
                        <div class="reiting">
                            <div class="reiting-points"></div>
                            <div class="feedback"> </div>
                        </div>
        </main>


    </section>

    <!--Subscription-->
    <section class="section-2">
        <h2>Sekite naujienas</h2>
        <p>Norite gauti pranešimus apie naujus kursus? Užsisakykite mūsų naujienlaiškį</p>
        <form action="" method="post">

            <!--Name input area-->
            <label for="name">Vardas:</label> <br>
            <input type="text" name="name" id="name"> <br> <br>

            <!--Email input area-->
            <label for="email">El. Paštas:</label> <br>
            <input type="email" name="email" id="email"> <br> <br>

            <!--Submit buttons-->
            <button type="submit" class="button">submit</button>


        </form>




        <form action="" method="post"></form>
    </section>

    <!-- Footer-->
    <footer>
        @ 2021 Vadimas Pliusninas
    </footer>
</body>

</html>