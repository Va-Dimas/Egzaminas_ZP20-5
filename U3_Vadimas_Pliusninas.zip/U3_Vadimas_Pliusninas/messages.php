<?php if (isset(kurso_populiarumas) : ?>
    <p>
        <?php 
            print kurso_populiarumas; 
    
        ?>
    </p>
<?php endif ?>
